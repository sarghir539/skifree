import "babel-polyfill";

test('true equals true', () => {
    expect(true).toBe(true);
});